<?php
 /*
  <script type="text/javascript" src="scripts/shBrushBash.js"></script>
  <script type="text/javascript" src="scripts/shBrushCpp.js"></script>
  <script type="text/javascript" src="scripts/shBrushCSharp.js"></script>
  <script type="text/javascript" src="scripts/shBrushCss.js"></script>
  <script type="text/javascript" src="scripts/shBrushDiff.js"></script>
  <script type="text/javascript" src="scripts/shBrushGroovy.js"></script>
  <script type="text/javascript" src="scripts/shBrushJava.js"></script>
  <script type="text/javascript" src="scripts/shBrushPlain.js"></script>
  <script type="text/javascript" src="scripts/shBrushPython.js"></script>
  <script type="text/javascript" src="scripts/shBrushRuby.js"></script>
  <script type="text/javascript" src="scripts/shBrushScala.js"></script>
  <script type="text/javascript" src="scripts/shBrushSql.js"></script>
  <script type="text/javascript" src="scripts/shBrushVb.js"></script>
  <script type="text/javascript" src="scripts/shBrushXml.js"></script>
 */
 
 $fileName = array(1 =>  "pleinjeu.inc.php", "pleinjeu.php", "pleinjeuGraph.php");
 $path = "../";
 $index_php = array(count($fileName));

 // Lecture des fichiers.
 for ($i = 1; $i <= count($fileName); $i++)
 {
  $handle = fopen ($path . $fileName[$i], "r"); $index_php[$i] = fread ($handle, filesize ($path . $fileName[$i])); fclose ($handle);
  $index_php[$i] = str_replace("<", "&lt;", $index_php[$i]); $index_php[$i] = str_replace(">", "&gt;", $index_php[$i]);
 };

?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!-- Page HTML compos�e et programm�e par S.M.C.J. -->
<html>
 <head>
  <title>Code source.</title>

  <meta http-equiv="content-language" content="fr" />
  <meta http-equiv="content-type"     content="text/html; charset=utf-8" />
  <meta       name="author"           content="S.M.C.J." />
  <meta       name="keywords"         content="Hydraule Orgue Orgao Organo Orgel Organ" />

  <meta       name="description"      content="Calcul du nombre de tuyaux identiques d'un plein-jeu." />

  <link rel="shortcut icon" href="../img/favicon.png" />
  <link rel="stylesheet" type="text/css" href="../styles.css" />

  <script type="text/javascript" src="scripts/shCore.js"></script>
  <script type="text/javascript" src="scripts/shBrushPhp.js"></script>
  <script type="text/javascript" src="scripts/shBrushJScript.js"></script>

  <link type="text/css" rel="stylesheet" href="styles/shCore.css" />
  <!-- shThemeDefault.css - shThemeDjango.css - shThemeEmacs.css - shThemeFadeToGrey.css - shThemeMidnight.css - shThemeRDark.css -->
  <link type="text/css" rel="stylesheet" href="styles/shThemeDefault.css" />

  <script type="text/javascript">
   SyntaxHighlighter.config.clipboardSwf = 'scripts/clipboard.swf';
   SyntaxHighlighter.all();
  </script>

 </head>

 <body text="#000000" link="#0000ff" vlink="#551a8b" alink="#ff0000">
  <table border="0" width="100%">

   <tr>
    <td align="center" valign="center">
     <br /><br /><h1><font color="#ff0000">L'ordinateur</font></h1>
     <h2><font color="#008000">D&eacute;bit et graphiques<br />de plein-jeux.</font></h2>
     <h3><font color="#000080">Code source.</font></h3>
    </td>

    <td align="right">
     <a href="http://hydraule.org/" target="_top"><img src="../img/hydraule.png" border="0" width="216" height="230" alt="L'Hydraule" title="L'Hydraule"></a>
    </td>
   </tr>
  </table>

  <br /><br />

  <h2 align="center"><font color="#008000">Le code.</font></h2>

  <blockquote>
<?php
 for ($i = 1; $i <= count($fileName); $i++)
 {
?>
  <h3 align="center"><font color="#000080"><?php echo($fileName[$i]); ?>.</font></h2>
   <pre class="brush:php">
<?php echo($index_php[$i]);?>
   </pre>

   <br /><br />

<?php
 };
?>
  </blockquote>
 
  <br /><br />

 </body>
</html>