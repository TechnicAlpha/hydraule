<?php

 // ************************************************************************************************
 // ***                 Les constantes déterminées dans ce fichier sont partagées                ***
 // *** par le script principal (./pleinjeu.php) et l'image graphique PNG (./pleinjeuGraph.php). ***
 // ************************************************************************************************

 // Noms des notes ; la traduction des NOMS DE NOTATION est faite automatiquement plus bas.
 $note[1] = array(0 => "Anglo-Saxonne", "C",  "C#",  "D",  "D#",  "E",  "F",  "F#",   "G",   "G#",  "A",  "A#",  "B");
 $note[2] = array(0 => "Allemande 1",   "C",  "C#",  "D",  "D#",  "E",  "F",  "F#",   "G",   "G#",  "A",   "B",  "H");
 $note[3] = array(0 => "Allemande 2",   "C",  "Cs",  "D",  "Ds",  "E",  "F",  "Fs",   "G",   "Gs",  "A",   "B",  "H");
 $note[4] = array(0 => "Allemande 3",   "C", "Cis",  "D", "Dis",  "E",  "F", "Fis",   "G",  "Gis",  "A", "Ais",  "H");
 $note[5] = array(0 => "Latine 1",     "Ut", "Ut#", "Ré", "Ré#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si");
 $note[6] = array(0 => "Latine 2",     "Ut", "Ut#", "Ré", "Mib", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "Sib", "Si");
 $note[7] = array(0 => "Dom Bedos",     "C",  "C#",  "D",  "Eb",  "E",  "F",  "F#",   "G",   "G#",  "A",  "Bb",  "B");

 // Noms par défaut des notes.
 $nbRanRom = array(1 =>  "I", "II", "III",  "IV",    "V",  "VI", "VII", "VIII",
                        "IX",  "X",  "XI", "XII", "XIII", "XIV",  "XV",  "XVI");
  
 // Définition des couleurs des rangs.
 $couleur  = array(1 => "#000000", "#ff0000", "#008000", "#0000ff", "#ff00ff", "#ffaa00", "#00ffff", "#ffa0a0",
                        "#909090", "#800000", "#ff00ff", "#ffaa00", "#00ff00", "#ffa0a0", "#909090", "#800000");

 // Nom des tessitures.
 $nomTessi  [0] = " - "   ; $nomTessi  [1] = "32'"    ; $nomTessi  [5] = "25'3/5" ; $nomTessi  [8] = "21'1/3" ;
 $nomTessi [13] = "16'"   ; $nomTessi [17] = "12'4/5" ; $nomTessi [20] = "10'2/3" ; $nomTessi [25] = "8'"     ;
 $nomTessi [29] = "6'2/5" ; $nomTessi [32] = "5'1/3"  ; $nomTessi [37] = "4'"     ; $nomTessi [41] = "3'1/5"  ;
 $nomTessi [44] = "2'2/3" ; $nomTessi [49] = "2'"     ; $nomTessi [53] = "1'3/5"  ; $nomTessi [56] = "1'1/3"  ;
 $nomTessi [61] = "1'"    ; $nomTessi [65] = "4/5'"   ; $nomTessi [68] = "2/3'"   ; $nomTessi [73] = "1/2'"   ;
 $nomTessi [77] = "2/5'"  ; $nomTessi [80] = "1/3'"   ; $nomTessi [85] = "1/4'"   ; $nomTessi [89] = "1/5'"   ;
 $nomTessi [92] = "1/6'"  ; $nomTessi [97] = "1/8'"   ; $nomTessi[101] = "1/10'"  ; $nomTessi[104] = "1/12'"  ;
 $nomTessi[109] = "1/16'" ; $nomTessi[113] = "1/20'"  ; $nomTessi[116] = "1/24'"  ; $nomTessi[121] = "1/32'"  ;
 
 // Convertit en binaire en formatant la chaîne avec les zéros de gauche.
 function deciBin($valeur) {return sprintf("%08s", decbin($valeur)); };

 // Encode une valeur numérique sur deux octets.
 function encodeVal($input)
 {
  //      |<----- Poids fort ----->|   |<- Poids faible ->|
  return chr(floor($input / 256)) . chr($input % 256);
 };

 // Décode une valeur numérique sur deux octets.
 function decodeVal($input)
 {
  //      |<---------- Poids fort ---------->|    |<---- Poids faible ----->|
  return (ord(substr($input, 0, 1)) * 256) + ord(substr($input, 1, 1));
 };
?>