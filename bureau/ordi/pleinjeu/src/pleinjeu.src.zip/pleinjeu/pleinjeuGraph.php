<?php

 // ***************************************************
 // *** Image graphique de plein jeu au format PNG. ***
 // ***************************************************

 // Les constantes déterminées dans ce fichier include sont partagées par le script principal (./pleinjeu.php).
 include("./pleinjeu.inc.php");

   $t1 = isset($_GET ['t1'])   ? $_GET ['t1']   : "";
   $t2 = isset($_GET ['t2'])   ? $_GET ['t2']   : "";
   $t3 = isset($_GET ['t3'])   ? $_GET ['t3']   : "";
 $haut = isset($_GET ['haut']) ? $_GET ['haut'] : 0;
  $bas = isset($_GET ['bas'])  ? $_GET ['bas']  : 0;

 // Analyse de la chaîne pour mettre les fractions des tessitures en exposant.
 function expoTessi($im, $x, $y, $chaine, $coul)
 {
  $place = strpos($chaine, "'");
  if (($place >= 1) && ($place != (strlen($chaine) - 1)))
  {
   imagestring ($im, 2, $x, $y, substr($chaine, 0, ($place + 1)), $coul);
   imagestring ($im, 1, ($x + 17), ($y - 2), substr($chaine, ($place + 1)), $coul);
  }
  else
  {
   imagestring ($im, 2, $x, $y, substr($chaine, 0, ($place + 1)), $coul);
  }
 }

 // +--------------------------------------------------------------+
 // | Récupération des variables à partir des chaînes transférées. |
 // +--------------------------------------------------------------+

 $chaine = base64_decode($t1);                                          // Décodage de la chaîne $t1.

 $noteCoche = "";                                                       // Notes du clavier.
 for ($i = 0; $i <= 7; $i++)
 {
  $chaine1 = decbin(ord(substr($chaine, $i, 1))); while (strlen($chaine1) < 8) {$chaine1 = "0" . $chaine1;}
  $noteCoche .= $chaine1;
 };
    $nbNot = strlen(rtrim(substr($noteCoche, 0, 61), "0"));             // Nombre de notes

    $nbRan =    decodeVal(substr($chaine,  8,                      2)); // Nombre de rangs.
    $nbRep =    decodeVal(substr($chaine, 10,                      2)); // Nombre de reprises.
   $notNot =    decodeVal(substr($chaine, 12,                      2)); // Notation des notes.
   $notOct =    decodeVal(substr($chaine, 14,                      2)); // Notation des octaves.
    $l_img =    decodeVal(substr($chaine, 16,                      2)); // Largeur de l'image graphique.
    $h_img =    decodeVal(substr($chaine, 18,                      2)); // Hauteur de l'image graphique.
 $formSort =    decodeVal(substr($chaine, 20,                      2)); // Format de sortie.
   $nomJeu = stripslashes(substr($chaine, 22, (strlen($chaine) - 22))); // Nom du jeu (255 octets maximum).

 // Valeurs des notes de reprises (index à 1 au contraire de pleinjeu.php).
 $chaine = base64_decode($t2);                                          // Décodage de la chaîne $t2.
 for ($i = 1; $i <= 16; $i++) {$repri[$i] = ord(substr($chaine, ($i - 1), 1)); };

 // Valeurs des tessitures (index à 1 au contraire de pleinjeu.php).
 $chaine = base64_decode($t3);                                          // Décodage de la chaîne $t3.
 for ($i = 1; $i <= 16; $i++)
 {
  for ($j = 1; $j <= 16; $j++) {$tessi[$i][$j] = ord(substr($chaine, ((($i - 1) * 16) + ($j - 1)), 2)); };
 };

 $nomFichier = $nomJeu . " " . $nbRanRom[$nbRan];
 header("Content-Type:image/png"); 
 header("Content-Disposition:filename=\"" . $nomFichier . ".png\"");

 // +----------------------------+
 // | Construction du graphique. +
 // +----------------------------+
 $im = imagecreate($l_img, $h_img); $l_img--; $h_img--; 

 // Détermination des couleurs.
 $fond = imagecolorallocate($im, 0xf5, 0xe9, 0xcf); imagecolortransparent($im, $fond);
 for ($i = 1; $i <= 16; $i++)
 {
  $couleur[$i] = imagecolorallocate($im, base_convert(substr($couleur[$i], 1, 2), 16, 10), base_convert(substr($couleur[$i], 3, 2), 16, 10), base_convert(substr($couleur[$i], 5, 2), 16, 10));
 };

 imagefill($im, 0, 0, $fond);

 // Marge des reprises et des tessitures et police de caractère employée.
 $mt = 50; $mr = 40; $police = 2; 

 // Largeur et hauteur du graphique ($lg et $hg).
 // On relève $haut pour pouvoir faire suivre les lignes sans rupture même si c'est de la triche.
 $haut++; $lg = ($l_img - $mt); $hg = ($h_img - $mr);

 // Nombre de tessitures présentes dans le graphique.
 $nbtessi = ($haut - $bas) + 1;

 // Largeur et hauteur PAR DEFAUT de chaque cellule du graphique ($lc et $hc).
 $lc = floor($lg / $nbNot); $hc = floor($hg / $nbtessi);
 for ($i = 1; $i <= $nbNot; $i++) {$x[$i] = $lc;}
 for ($i = 1; $i <= $nbtessi; $i++) {$y[$i] = $hc;}

 // Détermine et dispatche l'erreur.
 $lc_err = floor($lg % $nbNot);  $hc_err = floor($hg % $nbtessi);
 $j = 1; for ($i = 1; $i <= $lc_err; $i++) {$x[$j]++; $j += floor($nbNot / $lc_err);}
 $j = 1; for ($i = 1; $i <= $hc_err; $i++) {$y[$j]++; $j += floor($nbtessi / $hc_err);}

 // Positionne les X et les Y de manière progressive.
 $x[1] += ($mt - $lc - 1); for ($i = 2; $i <= $nbNot; $i++) {$x[$i] += $x[$i - 1];}
 $y[1] += ($mr - $hc - 1); for ($i = 2; $i <= $nbtessi; $i++) {$y[$i] += $y[$i - 1];}

 // En voiture...
 $repri[$nbRep + 1]  = $nbNot + 1;                         // Pour pouvoir passer la dernière reprise.
 for ($i = 1; $i <= $nbRan; $i++)                          // Boucle des rangs. 
 {
  for ($j = 1; $j <= $nbRep; $j++)                         // Boucle des reprises.
  {
   if ($tessi[$i][$j] != 0)                                // Cas des reprises vides (trous).
   {
    $vrainote = $tessi[$i][$j] + $repri[$j] - 1;           // Première note RÉELLE de la reprise.

    $decal = 0;                                            // Compte les doublures qui vont provoquer un décalage
    for ($k = 1; $k < $i; $k++)
    {
     if (($tessi[$k][$j] + $repri[$j] - 1) == $vrainote) {$decal++;}
    }

    $nbNotRep = $repri[$j + 1] - $repri[$j];               // Nombre de notes dans la reprise.
    if ($j == $nbRep) {$nbNotRep--;}                       // Dernière reprise plus courte d'une note.

    $x1 = $x[$repri[$j]];              $y1 = $y[($haut - $vrainote) + 1] - $decal;
    $x2 = $x[$repri[$j] + $nbNotRep];  $y2 = $y[($haut - $vrainote) - $nbNotRep + 1] - $decal;

    // Trace la reprise.
    imageline ($im, $x1, $y1, $x2, $y2, $couleur[$i]);
   }
  }
 }

 // Marque des tessitures plus graves au milieu de graphique.
 for ($i = 1; $i <= $nbRep; $i++)                         // Boucle des reprises.
 {
  $plusgrave = 121;                                       // Analyse la reprise la plus grave.
  for ($j = 1; $j <= $nbRan; $j++)                        // Boucle des rangs.
  {
   if ($plusgrave > $tessi[$j][$i]) {$plusgrave = $tessi[$j][$i];}
  }

  if ($plusgrave < $bas)
  {
   $vrainote = $plusgrave + $repri[$i] - 1;               // Première note RÉELLE de la reprise.
   $x1 = $x[$repri[$i]];  $y1 = $y[($haut - $vrainote) + 1];
   expoTessi($im, ($x1 - 33), ($y1 + 5), $nomTessi[$plusgrave], $couleur[1]);
  }
 }

 // Trace le cadre général.
 imagerectangle ($im, $x[1], $y[1], $x[$nbNot], $y[$nbtessi], $couleur[1]);
 imagestring ($im, 3, $mt, 5, $nomJeu . " " . $nbRanRom[$nbRan], $couleur[1]);

 // Lignes des reprises
 $repri[$nbRep + 1]--;                                    // Pour pouvoir afficher
 for ($i = 1; $i <= ($nbRep + 1); $i++)                   // la dernière note.
 {
  $chaine = $note[$notNot][(($repri[$i] - 1) % 12) + 1];

  // Passe le nom des notes en minuscules.
  if (($notOct == 2) && ($repri[$i] > 12)) {$chaine = strtolower($chaine);}

  if ($notOct == 1)                                       // Notation numérique.
  {
   $chaine .= (floor($repri[$i] / 12) + 1);
  }
  else                                                    // Notation allemande des octaves.
  {
   if (($repri[$i] >= 12) && ($repri[$i] < 25))           // Affiche le null.
   {
    $chaine .= "o";                                       // On attend que PHP gère l'UTF8.
   }
   if ($repri[$i] >= 25)                                  // Affiche les guillemets.
   {
    for ($j = 1; $j <= (floor($repri[$i] / 12) - 1); $j++) {$chaine .= "'";}
   }
  }

  // Retrait à gauche plus important pour la dernière note.
  if ($i == ($nbRep +1)) {$j = (6 * $notOct);} else {$j = 0;}

  imagestring ($im, $police, ($x[$repri[$i]] - $j), ($y[1] - 15), $chaine, $couleur[1]);
  imageline ($im, $x[$repri[$i]], $y[1], $x[$repri[$i]], $y[$nbtessi], $couleur[1]);
 }

 // Lignes des tessitures
 for ($i = 1; $i <= $nbtessi; $i++)
 {
  if (((($i - $haut) % 12) == 0 ) || ((($i + 7- $haut) % 12) == 0 ))
  {
   expoTessi($im, 10, ($y[$i] - 10), $nomTessi[($haut - $i + 1)], $couleur[1]);
   imageline ($im, $x[1], $y[$i], $x[$nbNot], $y[$i], $couleur[1]);
  }
 }

 imagepng($im); imagedestroy($im);

/*
 // Cadrillage éventuel (très utile pour la programmation).
 $gris = imagecolorallocate($im, 191, 191, 191);
 imagerectangle ($im, $mt, $mr, $l_img, $h_img, $gris);
 // Lignes verticales
 for ($i = 1; $i <= $nbNot; $i++) {imageline ($im, $x[$i], $mr, $x[$i], $h_img, $gris);}
 // Lignes horizontales
 for ($i = 1; $i <= $nbtessi; $i++) {imageline ($im, $mt, $y[$i], $l_img, $y[$i], $gris);}
*/

?>